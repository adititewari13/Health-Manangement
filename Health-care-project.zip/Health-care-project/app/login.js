
var express = require('express');
let bodyParser = require("body-parser");

let mongodb = require("mongodb");
const multer = require('multer');
let mongodbClient = mongodb.MongoClient;


// Checks and returns the user data based on the correct email and password combination...
let login = express.Router().post("/", (req, res) => {
    mongodbClient.connect("mongodb://localhost:27017/health", (err, client) => {
        if (err) {
            throw err;
        } else {
            var db = client.db("health");
            db.collection("details").find({}).toArray((err, emp) => {
                if (err) {
                    throw err;
                } else {
                    console.log(req.body.password);
                    for (let i = 0; i < emp.length; i++) {
                        if (emp[i].email == req.body.email && emp[i].password == req.body.password) {
                            res.json(emp[i]);
                            return;
                        }
                    }
                    res.json("INVALID CREDENTIALS!!!");
                }
            });
        }
    });
});

module.exports = login;



